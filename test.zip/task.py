from flask import Flask, render_template

app = Flask(__name__)


@app.route('/вход1')
def index():
    return render_template('user_info.html')


@app.route('/вход2')
def index2():
    return render_template('job_info.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
